.. _Bandwidth:

=============================================
Bandwidth
=============================================

.. doxygenclass:: champsim::bandwidth
   :members:

