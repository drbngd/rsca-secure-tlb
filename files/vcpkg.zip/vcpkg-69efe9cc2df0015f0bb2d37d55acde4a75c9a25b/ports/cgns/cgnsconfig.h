#ifndef CGNSCONFIG_H
#define CGNSCONFIG_H

#include "cgnstypes.h"

#endif