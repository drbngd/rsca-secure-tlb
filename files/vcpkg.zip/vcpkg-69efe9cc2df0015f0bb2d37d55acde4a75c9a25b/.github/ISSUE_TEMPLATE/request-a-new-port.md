---
name: Request a new port
about: Request a new port/library that vcpkg should support
title: "[New Port Request] <library name here>"
labels: "category:new-port,info:good-first-issue"
assignees: ''

---

Library name:

Library description:

Source repository URL:

Project homepage (if different from the source repository):

Anything else that is useful to know when adding (such as optional features the library may have that should be included):
